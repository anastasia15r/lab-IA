import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import streamlit as st
from fuzzy_model import DOMAINS, LABELS, RULES, trapmf, predict

st.set_page_config(page_title='Лабораторная №4 — прогноз осадков',page_icon='🌦️',layout='wide')
st.title('🌦️ Прогноз вероятности осадков')
st.caption('Лабораторная работа №4 · Вариант 1 · Нечеткий вывод Мамдани (min/max, центроид)')
st.info('Учебная экспертная оценка по заданным правилам, а не статистически калиброванный метеорологический прогноз.')

with st.form('inputs'):
    a,b,c=st.columns(3)
    t=a.text_input('Температура (°C), −30…50','20')
    h=b.text_input('Относительная влажность (%), 0…100','65')
    p=c.text_input('Атмосферное давление (гПа), 950…1050','1015')
    submitted=st.form_submit_button('Рассчитать прогноз',type='primary')

if submitted:
    try:
        values={'temperature':t.replace(',','.'),'humidity':h.replace(',','.'),'pressure':p.replace(',','.')}
        st.session_state['values']=values
        st.session_state['result']=predict(values)
        st.session_state.pop('error',None)
    except (ValueError,RuntimeError) as exc:
        st.session_state['error']=str(exc)
        st.session_state.pop('result',None)
if 'error' in st.session_state: st.error(st.session_state['error'])

if 'result' in st.session_state:
    r=st.session_state['result']
    col1,col2=st.columns(2)
    col1.metric('Оценка вероятности осадков',f'{r.score:.2f} %')
    col2.metric('Лингвистическая категория',r.category)
    tips={'Низкая':'По модели осадки маловероятны.','Средняя':'По модели осадки возможны.','Высокая':'По модели вероятность осадков повышенная.'}
    st.success(tips[r.category])
    st.subheader('Фаззификация: степени принадлежности')
    df=pd.DataFrame([{'Переменная':key,'Терм':term,'μ':round(deg,3)} for key,items in r.degrees.items() for term,deg in items.items()])
    st.dataframe(df,hide_index=True,use_container_width=True)
    st.subheader('Функции принадлежности входных и выходной переменных')
    names={'temperature':'Температура (°C)','humidity':'Влажность (%)','pressure':'Давление (гПа)','precipitation':'Вероятность осадков (%)'}
    fig,axes=plt.subplots(2,2,figsize=(12,7))
    for ax,key in zip(axes.flat,names):
        low,high=DOMAINS[key]; x=np.linspace(low,high,1001)
        for term,points in LABELS[key].items(): ax.plot(x,trapmf(x,points),label=term,linewidth=2)
        if key!='precipitation': ax.axvline(float(st.session_state['values'][key]),color='black',linestyle='--',alpha=.6)
        else: ax.axvline(r.score,color='black',linestyle='--',label=f'Центроид {r.score:.2f}')
        ax.set(title=names[key],xlabel=names[key],ylabel='μ',ylim=(-.05,1.1));ax.legend(fontsize=8);ax.grid(alpha=.2)
    fig.tight_layout();st.pyplot(fig);plt.close(fig)
    st.subheader('Агрегация и дефаззификация')
    fig,ax=plt.subplots(figsize=(11,3.6))
    for term,y in r.components.items(): ax.plot(r.x,y,label=f'Агрегировано: {term}',alpha=.7)
    ax.fill_between(r.x,r.aggregate,alpha=.25,color='steelblue',label='Объединение max')
    ax.plot(r.x,r.aggregate,color='navy',linewidth=2)
    ax.axvline(r.score,color='crimson',linestyle='--',label=f'Центроид = {r.score:.2f}%')
    ax.set(xlabel='Вероятность осадков (%)',ylabel='μ',ylim=(-.05,1.1));ax.grid(alpha=.2);ax.legend(ncol=2);st.pyplot(fig);plt.close(fig)
    st.subheader('Сработавшие правила')
    rows=[]
    for row in r.activations:
        if row['strength']>0:
            cond=f' {row["operator"]} '.join(f'{v}={term}' for v,term in row['conditions'])
            rows.append({'№':row['id'],'Условие':cond,'Следствие':row['outcome'],'Сила':round(row['strength'],3)})
    st.dataframe(pd.DataFrame(rows),hide_index=True,use_container_width=True)

with st.expander('Полная база правил (16 IF–THEN)'):
    for i,(op,conditions,outcome) in enumerate(RULES,1):
        st.write(f'{i}. ЕСЛИ '+f' {op} '.join(f'{v} — {term}' for v,term in conditions)+f', ТО вероятность — {outcome.lower()}.')
st.caption('Чтобы повторить расчет, измените любое поле и нажмите «Рассчитать прогноз».')

"""Mamdani fuzzy precipitation likelihood model; educational, not calibrated weather forecast."""
from dataclasses import dataclass
import numpy as np

DOMAINS = {'temperature': (-30., 50.), 'humidity': (0., 100.), 'pressure': (950., 1050.), 'precipitation': (0., 100.)}
LABELS = {
 'temperature': {'Низкая': (-30,-30,0,15), 'Умеренная': (5,15,25,35), 'Высокая': (25,35,50,50)},
 'humidity': {'Низкая': (0,0,25,45), 'Средняя': (30,50,65,80), 'Высокая': (65,85,100,100)},
 'pressure': {'Низкое': (950,950,975,1005), 'Среднее': (990,1010,1020,1040), 'Высокое': (1025,1045,1050,1050)},
 'precipitation': {'Низкая': (0,0,15,40), 'Средняя': (25,45,55,75), 'Высокая': (60,85,100,100)}
}
# antecedents: (variable, term); operator applies between all antecedents.
RULES = [
 ('AND', [('temperature','Низкая'),('humidity','Высокая')], 'Высокая'),
 ('AND', [('temperature','Умеренная'),('humidity','Высокая')], 'Высокая'),
 ('AND', [('temperature','Высокая'),('pressure','Высокое')], 'Низкая'),
 ('AND', [('temperature','Высокая'),('humidity','Низкая')], 'Низкая'),
 ('AND', [('pressure','Низкое'),('humidity','Высокая')], 'Высокая'),
 ('AND', [('pressure','Среднее'),('humidity','Средняя')], 'Средняя'),
 ('AND', [('temperature','Низкая'),('pressure','Низкое')], 'Высокая'),
 ('AND', [('temperature','Умеренная'),('pressure','Высокое')], 'Низкая'),
 ('AND', [('temperature','Высокая'),('humidity','Средняя')], 'Средняя'),
 ('OR', [('humidity','Высокая'),('pressure','Низкое')], 'Высокая'),
 ('AND', [('humidity','Низкая'),('pressure','Высокое')], 'Низкая'),
 ('AND', [('temperature','Умеренная'),('humidity','Низкая')], 'Низкая'),
 ('AND', [('temperature','Низкая'),('humidity','Средняя')], 'Средняя'),
 ('AND', [('temperature','Умеренная'),('humidity','Средняя')], 'Средняя'),
 ('AND', [('temperature','Высокая'),('pressure','Низкое')], 'Средняя'),
 ('OR', [('humidity','Низкая'),('pressure','Высокое')], 'Низкая'),
]

def trapmf(x, points):
    a,b,c,d = points
    x=np.asarray(x,dtype=float)
    left=np.where(b==a, np.where(x>=b,1.,0.), np.clip((x-a)/(b-a) if b!=a else 0.,0.,1.))
    right=np.where(d==c, np.where(x<=c,1.,0.), np.clip((d-x)/(d-c) if d!=c else 0.,0.,1.))
    return np.maximum(0.,np.minimum(left,right))

def validate(values):
    if set(values) != {'temperature','humidity','pressure'}:
        raise ValueError('Необходимо указать температуру, влажность и давление.')
    cleaned={}
    for k,v in values.items():
        if v is None or isinstance(v,str) and not v.strip():
            raise ValueError(f'Поле «{k}» не заполнено.')
        try: val=float(v)
        except (TypeError,ValueError): raise ValueError(f'Поле «{k}» должно быть числом.') from None
        if not np.isfinite(val): raise ValueError(f'Поле «{k}» должно быть конечным числом.')
        low,high=DOMAINS[k]
        if not low<=val<=high: raise ValueError(f'Значение «{k}» должно быть в диапазоне {low:g}…{high:g}.')
        cleaned[k]=val
    return cleaned

@dataclass
class Result:
    score:float
    category:str
    degrees:dict
    activations:list
    x:np.ndarray
    aggregate:np.ndarray
    components:dict

def predict(values):
    values=validate(values)
    degrees={k:{term:float(trapmf(v,p)) for term,p in LABELS[k].items()} for k,v in values.items()}
    x=np.linspace(0,100,2001)
    components={name:np.zeros_like(x) for name in LABELS['precipitation']}
    activations=[]
    for i,(op,conditions,outcome) in enumerate(RULES,1):
        parts=[degrees[var][term] for var,term in conditions]
        strength=min(parts) if op=='AND' else max(parts)
        clipped=np.minimum(strength,trapmf(x,LABELS['precipitation'][outcome]))
        components[outcome]=np.maximum(components[outcome],clipped)
        activations.append({'id':i,'operator':op,'conditions':conditions,'outcome':outcome,'strength':strength})
    aggregate=np.maximum.reduce(list(components.values()))
    area=np.trapezoid(aggregate,x) if hasattr(np,'trapezoid') else np.trapz(aggregate,x)
    if area<=1e-12: raise RuntimeError('Не активировано ни одного правила. Проверьте модель.')
    integral=np.trapezoid(x*aggregate,x) if hasattr(np,'trapezoid') else np.trapz(x*aggregate,x)
    score=float(integral/area)
    category=max(LABELS['precipitation'],key=lambda t:float(trapmf(score,LABELS['precipitation'][t])))
    return Result(score,category,degrees,activations,x,aggregate,components)

if __name__=='__main__':
    for case in ({'temperature':5,'humidity':95,'pressure':975},{'temperature':38,'humidity':15,'pressure':1045},{'temperature':20,'humidity':55,'pressure':1015}):
        result=predict(case)
        print(case,round(result.score,2),result.category)

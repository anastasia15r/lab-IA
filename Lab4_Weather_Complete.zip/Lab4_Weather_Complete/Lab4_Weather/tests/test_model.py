import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import pytest
from fuzzy_model import predict,trapmf,RULES

def test_nine_or_more_rules(): assert len(RULES)>=9

def test_and_or(): assert {'AND','OR'} <= {r[0] for r in RULES}

def test_membership_overlap():
    assert 0<trapmf(35,(0,0,30,50))<1
    assert 0<trapmf(35,(20,40,60,60))<1

@pytest.mark.parametrize('case',[
 {'temperature':5,'humidity':95,'pressure':975},
 {'temperature':38,'humidity':15,'pressure':1045},
 {'temperature':20,'humidity':55,'pressure':1015},
 {'temperature':-30,'humidity':0,'pressure':950},
 {'temperature':50,'humidity':100,'pressure':1050},
])
def test_prediction(case):
    result=predict(case)
    assert 0<=result.score<=100
    assert result.aggregate.max()>0
    assert result.category in ('Низкая','Средняя','Высокая')

@pytest.mark.parametrize('case',[
 {'temperature':'','humidity':50,'pressure':1010},
 {'temperature':'abc','humidity':50,'pressure':1010},
 {'temperature':100,'humidity':50,'pressure':1010},
 {'temperature':20,'humidity':float('nan'),'pressure':1010},
 {'temperature':20,'humidity':50},
])
def test_invalid(case):
    with pytest.raises(ValueError): predict(case)

def test_wet_vs_dry():
    wet=predict({'temperature':5,'humidity':95,'pressure':975}).score
    dry=predict({'temperature':38,'humidity':15,'pressure':1045}).score
    assert wet>dry

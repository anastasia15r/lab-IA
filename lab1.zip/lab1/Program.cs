﻿using System;

class Program
{
    enum State
    {
        q0,
        q1,
        q2,
        q3,
        q4,
        q5,
        q6,
        Error
    }

    static State GetNextState(State state, char symbol)
    {
        switch (state)
        {
            case State.q0:
                if (symbol == 'a')
                    return State.q1;
                return State.Error;

            case State.q1:
                if (symbol == 'b')
                    return State.q2;
                return State.Error;

            case State.q2:
                if (symbol == 'c')
                    return State.q3;
                return State.Error;

            case State.q3:
                if (symbol == 'd')
                    return State.q4;
                return State.Error;

            case State.q4:
                if (symbol == 'a')
                    return State.q1;

                if (symbol == 'e')
                    return State.q5;

                return State.Error;

            case State.q5:
                if (symbol == 'f')
                    return State.q6;
                return State.Error;

            case State.q6:
                if (symbol == 'e')
                    return State.q5;
                return State.Error;

            case State.Error:
                return State.Error;

            default:
                return State.Error;
        }
    }

    static bool CheckWord(string word)
    {
        State currentState = State.q0;

        foreach (char symbol in word)
        {
            currentState = GetNextState(currentState, symbol);

            if (currentState == State.Error)
                return false;
        }

        return currentState == State.q6;
    }

    static void Main()
    {
        Console.WriteLine("==============================================");
        Console.WriteLine("       Лабораторная работа №1");
        Console.WriteLine("   Детерминированный конечный автомат");
        Console.WriteLine("==============================================");
        Console.WriteLine();

        Console.WriteLine("Заданный язык:");
        Console.WriteLine("(abcd)^n(ef)^m, где n >= 1 и m >= 1");
        Console.WriteLine();

        Console.Write("Введите слово: ");

        string word = Console.ReadLine() ?? "";

        Console.WriteLine();

        if (CheckWord(word))
        {
            Console.WriteLine(
                "Результат: слово принадлежит заданному языку."
            );
        }
        else
        {
            Console.WriteLine(
                "Результат: слово НЕ принадлежит заданному языку."
            );
        }

        Console.WriteLine();
        Console.WriteLine("Нажмите любую клавишу для завершения...");
        Console.ReadKey();
    }
}
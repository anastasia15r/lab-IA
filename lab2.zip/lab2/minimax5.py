
"""
Лабораторная работа: "Мини-макс с альфа-бета отсечением"
Вариант 5: глубина дерева = 7, ширина дерева = 2,
особенность — часть листьев сделаны одинаковыми, чтобы проверить
равенство (эквивалентность) оптимальных путей.
 
Структура файла:
1. Построение игрового дерева заданной глубины и ширины.
2. Намеренное дублирование части листовых значений.
3. Обычный минимакс (полный перебор) со счётчиком узлов.
4. Минимакс с альфа-бета отсечением со счётчиком узлов.
5. Поиск ВСЕХ оптимальных путей (с учётом равных значений).
6. Сравнение эффективности (узлы, время) + анализ равенства путей.
"""
 
import math
import random
import time
 
# ---------------------------------------------------------------
# 1. ПАРАМЕТРЫ ВАРИАНТА 5
# ---------------------------------------------------------------
DEPTH = 7            # глубина дерева (число полуходов до листа)
WIDTH = 2             # ширина дерева (число потомков у каждого узла)
LEAF_MIN, LEAF_MAX = -50, 50   # диапазон случайных значений листьев
DUPLICATE_FRACTION = 0.25      # доля листьев, которым присвоим "чужое" значение
RANDOM_SEED = 8
 
random.seed(RANDOM_SEED)
 
 
# ---------------------------------------------------------------
# 2. УЗЕЛ ДЕРЕВА
# ---------------------------------------------------------------
class Node:
    """
    Узел игрового дерева.
    depth     — глубина узла (0 = корень).
    children  — список потомков (пусто у листьев).
    value     — значение (задано только у листьев).
    id        — уникальный номер узла, нужен для отладки/вывода путей.
    """
    _counter = 0
 
    __slots__ = ("depth", "children", "value", "id")
 
    def __init__(self, depth):
        self.depth = depth
        self.children = []
        self.value = None
        self.id = Node._counter
        Node._counter += 1
 
    def is_leaf(self):
        return not self.children
 
 
def build_tree(depth, max_depth):
    """Рекурсивно строит полное дерево глубины max_depth и ширины WIDTH."""
    node = Node(depth)
    if depth == max_depth:
        node.value = random.randint(LEAF_MIN, LEAF_MAX)
    else:
        for _ in range(WIDTH):
            node.children.append(build_tree(depth + 1, max_depth))
    return node
 
 
def collect_leaves(node, leaves):
    if node.is_leaf():
        leaves.append(node)
    else:
        for c in node.children:
            collect_leaves(c, leaves)
 
 
def make_leaves_partially_equal(root, fraction):
    """
    Особенность варианта 5: часть листьев делаем одинаковыми.
    Берём случайные пары листьев и присваиваем одному значение другого.
    Это создаёт ситуации, где несколько разных путей в дереве
    приводят к одному и тому же результату игры.
    """
    leaves = []
    collect_leaves(root, leaves)
    n = len(leaves)
    k = max(1, int(n * fraction))
    targets = random.sample(leaves, k)
    sources = random.sample(leaves, k)
    for t, s in zip(targets, sources):
        t.value = s.value
    return leaves
 
 
# ---------------------------------------------------------------
# 3. ОБЫЧНЫЙ МИНИМАКС (без отсечения)
# ---------------------------------------------------------------
def minimax(node, is_maximizing, counter):
    counter[0] += 1  # считаем каждый посещённый узел
    if node.is_leaf():
        return node.value
 
    if is_maximizing:
        best = -math.inf
        for child in node.children:
            best = max(best, minimax(child, False, counter))
        return best
    else:
        best = math.inf
        for child in node.children:
            best = min(best, minimax(child, True, counter))
        return best
 
 
# ---------------------------------------------------------------
# 4. МИНИМАКС С АЛЬФА-БЕТА ОТСЕЧЕНИЕМ
# ---------------------------------------------------------------
def minimax_alpha_beta(node, is_maximizing, alpha, beta, counter):
    counter[0] += 1
    if node.is_leaf():
        return node.value
 
    if is_maximizing:
        best = -math.inf
        for child in node.children:
            val = minimax_alpha_beta(child, False, alpha, beta, counter)
            best = max(best, val)
            alpha = max(alpha, best)
            if alpha >= beta:
                break  # БЕТА-отсечение: MIN-родитель выше уже не выберет эту ветку
        return best
    else:
        best = math.inf
        for child in node.children:
            val = minimax_alpha_beta(child, True, alpha, beta, counter)
            best = min(best, val)
            beta = min(beta, best)
            if alpha >= beta:
                break  # АЛЬФА-отсечение
        return best
 
 
# ---------------------------------------------------------------
# 5. ПОИСК ВСЕХ ОПТИМАЛЬНЫХ ПУТЕЙ (анализ равенства путей)
# ---------------------------------------------------------------
def find_optimal_paths(node, is_maximizing):
    """
    Полный обход (без отсечения!), который возвращает:
      value  — оптимальное значение в этом узле,
      paths  — список ВСЕХ путей (списков id узлов) от этого узла до листа,
               которые достигают именно этого оптимального значения.
    Так как часть листьев одинаковы, путей, дающих один и тот же
    результат, может быть несколько — это и есть "равенство путей".
    """
    if node.is_leaf():
        return node.value, [[node.id]]
 
    child_results = [find_optimal_paths(c, not is_maximizing) for c in node.children]
    values = [v for v, _ in child_results]
    best_value = max(values) if is_maximizing else min(values)
 
    best_paths = []
    for c, (v, paths) in zip(node.children, child_results):
        if v == best_value:
            for p in paths:
                best_paths.append([node.id] + p)
 
    return best_value, best_paths
 
 
# ---------------------------------------------------------------
# 6. ЗАПУСК И СРАВНЕНИЕ
# ---------------------------------------------------------------
def main():
    root = build_tree(0, DEPTH)
    leaves = make_leaves_partially_equal(root, DUPLICATE_FRACTION)
 
    print("=" * 60)
    print(f"Вариант 5 — глубина={DEPTH}, ширина={WIDTH}")
    print(f"Всего листьев: {len(leaves)}; из них искусственно продублировано: "
          f"{int(len(leaves) * DUPLICATE_FRACTION)}")
    print("=" * 60)
 
    # --- обычный минимакс ---
    counter_plain = [0]
    t0 = time.perf_counter()
    value_plain = minimax(root, True, counter_plain)
    t1 = time.perf_counter()
 
    # --- минимакс с альфа-бета ---
    counter_ab = [0]
    t2 = time.perf_counter()
    value_ab = minimax_alpha_beta(root, True, -math.inf, math.inf, counter_ab)
    t3 = time.perf_counter()
 
    print(f"\nРезультат обычного минимакса     : {value_plain}")
    print(f"Результат минимакса с альфа-бета  : {value_ab}")
    assert value_plain == value_ab, "Значения должны совпадать!"
 
    print("\n--- Эффективность ---")
    print(f"{'Алгоритм':<25}{'Узлов проверено':<20}{'Время (сек)':<15}")
    print(f"{'Обычный минимакс':<25}{counter_plain[0]:<20}{t1 - t0:.6f}")
    print(f"{'Альфа-бета минимакс':<25}{counter_ab[0]:<20}{t3 - t2:.6f}")
 
    saved = counter_plain[0] - counter_ab[0]
    percent = saved / counter_plain[0] * 100
    print(f"\nОтсечено узлов: {saved} ({percent:.1f}% от общего числа проверок)")
 
    # --- анализ равенства путей ---
    best_value, all_optimal_paths = find_optimal_paths(root, True)
    print("\n--- Анализ равенства путей (особенность варианта 5) ---")
    print(f"Оптимальное значение игры: {best_value}")
    print(f"Количество различных путей от корня до листа, "
          f"дающих это оптимальное значение: {len(all_optimal_paths)}")
    if len(all_optimal_paths) > 1:
        print("Пример первых трёх таких путей (по id узлов):")
        for p in all_optimal_paths[:3]:
            print("  ", p)
        print("\nВывод: из-за одинаковых значений в листьях несколько разных "
              "последовательностей ходов приводят к одинаковому итогу игры. "
              "Alpha-beta отсечение находит только ОДИН из этих путей "
              "(первый по порядку обхода), но само оптимальное значение "
              "остаётся верным.")
    else:
        print("В этом запуске совпадение значений не привело к появлению "
              "нескольких оптимальных путей — можно увеличить "
              "DUPLICATE_FRACTION и запустить снова.")
 
 
if __name__ == "__main__":
    main()
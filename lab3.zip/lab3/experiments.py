"""
Эксперименты к лабораторной (вариант №5). Запуск:  python experiments.py
Результаты: results/results.json, results/tables.md, results/*.png

Каждая конфигурация прогоняется на SEEDS разных случайных сценах, значения усредняются.
Параметры конфигурации задаются словарём {"раздел.параметр": значение} поверх Config().
"""
from __future__ import annotations

import json
import os
from concurrent.futures import ProcessPoolExecutor

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

import migration as m

STEPS = 2000          # длина одного прогона (5 сезонов по 400 шагов)
WARMUP = 200          # первые шаги не учитываются в средних
SAMPLE = 10           # метрики считаются каждые SAMPLE шагов
SEEDS = list(range(8))
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "results")

# палитра, различимая при дальтонизме (Okabe-Ito)
BLUE, ORANGE, GREEN, GREY = "#0072B2", "#D55E00", "#009E73", "#666666"


def make_cfg(over: dict) -> m.Config:
    cfg = m.Config()
    for key, val in over.items():
        section, attr = key.split(".")
        setattr(getattr(cfg, section), attr, val)
    return cfg


# ----------------------------------------------------------------------------
# Один прогон (сезоны, голод/жажда, хищники)
# ----------------------------------------------------------------------------
def job(args):
    over, seed = args
    cfg = make_cfg(over)
    w = m.World(cfg, seed=seed)
    rec = []
    for t in range(STEPS):
        w.step()
        if t >= WARMUP and t % SAMPLE == 0:
            mm = m.metrics(w)
            al = w.alive
            needy = float((np.maximum(w.hunger, w.thirst)[al] > 0.8).mean()) if al.any() else 0.0
            res = w.zkind != m.SAFE
            avail = float((w.zamt[res] >= cfg.res.min_available).mean())
            if mm["alive"] == 0:        # популяция вымерла - метрики группы не определены
                continue
            rec.append((mm["groups"], mm["largest"], mm["need"], needy, mm["panic"], avail))
    r = np.mean(rec, axis=0) if rec else np.full(6, np.nan)
    return dict(survivors=float(w.alive.sum()) / cfg.animal.n_agents, kills=w.kills,
                groups=r[0], largest=r[1], need=r[2], needy=r[3], panic=r[4], avail=r[5])


def sweep(pool, configs: list[tuple[str, dict]]) -> list[dict]:
    jobs = [(over, s) for _, over in configs for s in SEEDS]
    res = list(pool.map(job, jobs))
    out = []
    for i, (label, over) in enumerate(configs):
        chunk = res[i * len(SEEDS):(i + 1) * len(SEEDS)]
        row = dict(label=label, over=over)
        for k in chunk[0]:
            vals = np.array([c[k] for c in chunk], dtype=float)
            row[k] = float(vals.mean())
            row[k + "_sd"] = float(vals.std())
        out.append(row)
    return out


# ----------------------------------------------------------------------------
# Эксперимент 4: угроза-импульс (распад стаи и восстановление структуры)
# ----------------------------------------------------------------------------
PULSE_START, PULSE_END, PULSE_T = 300, 450, 900


def pulse_job(args):
    threat_radius, seed = args
    cfg = make_cfg({"env.season_length": 10**9, "animal.hunger_rate": 0.0,
                    "animal.thirst_rate": 0.0, "pred.n": 1, "pred.catch_radius": 0.0,
                    "animal.threat_radius": threat_radius})
    w = m.World(cfg, seed=seed)
    far = np.array([-1e5, -1e5])
    class_step = m.World._step_predators
    w.ppos[0] = far
    w._step_predators = lambda: None                    # хищника пока нет
    ts, largest, groups, panic = [], [], [], []
    for t in range(PULSE_T):
        if t == PULSE_START:                            # хищник появляется рядом со стаей
            del w._step_predators
            w.ppos[0] = np.clip(w.pos.mean(0) + np.array([30.0, 0.0]), 0, w.size)
        if t == PULSE_END:                              # хищник уходит
            w._step_predators = lambda: None
            w.ppos[0] = far
        w.step()
        if t % 5 == 0:
            mm = m.metrics(w)
            ts.append(t); largest.append(mm["largest"]); groups.append(mm["groups"])
            panic.append(mm["panic"])
    return np.array(ts), np.array(largest), np.array(groups), np.array(panic)


# ----------------------------------------------------------------------------
# Таблицы и графики
# ----------------------------------------------------------------------------
def md_table(title, rows, cols, note=""):
    head = "| Конфигурация | " + " | ".join(c[1] for c in cols) + " |"
    sep = "|---|" + "---|" * len(cols)
    lines = [f"### {title}", "", head, sep]
    for r in rows:
        cells = []
        for key, _, fmt in cols:
            if np.isnan(r[key]):
                cells.append("—")           # группа вымерла, метрика не определена
            else:
                cells.append(f"{r[key]:{fmt}} ± {r[key + '_sd']:{fmt}}")
        lines.append(f"| {r['label']} | " + " | ".join(cells) + " |")
    if note:
        lines += ["", note]
    return "\n".join(lines) + "\n"


def style_axes(ax):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.grid(axis="y", color="#dddddd", lw=0.6)
    ax.set_axisbelow(True)


def fig_snapshots(path):
    cfg = m.Config()
    w = m.World(cfg, seed=3)
    times = [0, 150, 400, 700, 1000, 1500]
    fig, axes = plt.subplots(2, 3, figsize=(15, 7.5))
    for ax, tt in zip(axes.ravel(), times):
        while w.t < tt:
            w.step()
        sc = m.init_scene(ax, w)
        m.update_scene(sc, w)
        ax.set_title(f"t = {w.t}, {m.SEASONS[w.season]}", fontsize=10)
        ax.set_xticks([]); ax.set_yticks([])
    fig.suptitle("Базовый сценарий: зелёные - пища, голубые - вода, пунктир - убежища, "
                 "красные треугольники - хищник; оранжевые стрелки - животные в панике", fontsize=10)
    fig.tight_layout()
    fig.savefig(path, dpi=110)
    plt.close(fig)


def fig_heatmap(rows, path):
    dep = sorted({r["over"]["res.depletion_rate"] for r in rows})
    reg = sorted({r["over"]["res.regen_rate"] for r in rows})
    grid = np.zeros((len(dep), len(reg)))
    for r in rows:
        grid[dep.index(r["over"]["res.depletion_rate"]), reg.index(r["over"]["res.regen_rate"])] = r["need"]
    fig, ax = plt.subplots(figsize=(5.6, 4.4))
    im = ax.imshow(grid, cmap="Blues", vmin=0.3, vmax=1.0, origin="lower")
    ax.set_xticks(range(len(reg)), [f"{v}" for v in reg])
    ax.set_yticks(range(len(dep)), [f"{v}" for v in dep])
    ax.set_xlabel("скорость восстановления ресурсов (за шаг)")
    ax.set_ylabel("скорость исчезновения ресурсов (за шаг)")
    for i in range(len(dep)):
        for j in range(len(reg)):
            ax.text(j, i, f"{grid[i, j]:.2f}", ha="center", va="center",
                    color="white" if grid[i, j] > 0.7 else "#222222", fontsize=11)
    ax.set_title("Средняя потребность в еде/воде (0 - сыты, 1 - голод)", fontsize=10)
    fig.colorbar(im, ax=ax, shrink=0.8)
    fig.tight_layout()
    fig.savefig(path, dpi=120)
    plt.close(fig)


def fig_predators(rows_n, rows_v, path):
    fig, axes = plt.subplots(1, 2, figsize=(9.5, 3.8), sharey=True)
    for ax, rows, xlabel in ((axes[0], rows_n, "число хищников (скорость 2.4)"),
                             (axes[1], rows_v, "скорость хищников (2 хищника)")):
        x = np.arange(len(rows))
        ax.bar(x, [r["survivors"] for r in rows], yerr=[r["survivors_sd"] for r in rows],
               color=BLUE, width=0.6, capsize=3, ecolor=GREY)
        ax.set_xticks(x, [r["label"] for r in rows])
        ax.set_xlabel(xlabel)
        style_axes(ax)
    axes[0].set_ylabel("доля выживших к t = 2000")
    axes[0].set_ylim(0, 1.05)
    fig.tight_layout()
    fig.savefig(path, dpi=120)
    plt.close(fig)


def fig_pulse(curves, path):
    fig, axes = plt.subplots(2, 1, figsize=(8.5, 6), sharex=True)
    colors = {10: BLUE, 20: ORANGE, 35: GREEN}
    for tr, (ts, largest, groups, panic) in curves.items():
        axes[0].plot(ts, largest, color=colors[tr], lw=1.8, label=f"радиус угрозы {tr}")
        axes[1].plot(ts, groups, color=colors[tr], lw=1.8, label=f"радиус угрозы {tr}")
    for ax in axes:
        ax.axvspan(PULSE_START, PULSE_END, color="#f2d0c4", alpha=0.6, lw=0)
        style_axes(ax)
    axes[0].set_ylabel("доля животных в крупнейшей группе")
    axes[1].set_ylabel("число групп")
    axes[1].set_xlabel("шаг симуляции (заливка - хищник рядом со стаей)")
    axes[0].legend(frameon=False, loc="lower left")
    fig.tight_layout()
    fig.savefig(path, dpi=120)
    plt.close(fig)


# ----------------------------------------------------------------------------
def main():
    os.makedirs(OUT, exist_ok=True)
    NOPRED = {"pred.n": 0}
    results, md = {}, ["# Результаты экспериментов (среднее ± стандартное отклонение по %d сценам)\n" % len(SEEDS),
                       f"Длина прогона {STEPS} шагов, сезон 400 шагов, метрики усреднены по шагам {WARMUP}..{STEPS}.\n"]
    with ProcessPoolExecutor() as pool:
        # E0: калибровка скорости роста потребностей
        e0 = sweep(pool, [(f"{hr}", {**NOPRED, "animal.hunger_rate": hr, "animal.thirst_rate": hr})
                          for hr in (0.003, 0.0015, 0.001, 0.0005)])
        results["E0"] = e0
        md.append(md_table("E0. Темп роста голода и жажды за шаг (хищников нет)", e0,
                           [("need", "средняя потребность", ".2f"), ("needy", "доля голодных (>0.8)", ".2f")]))

        # E1: исчезновение и восстановление ресурсов
        cfgs = [(f"исч. {d}, восст. {r}", {**NOPRED, "res.depletion_rate": d, "res.regen_rate": r})
                for d in (0.003, 0.01, 0.03) for r in (0.001, 0.004, 0.015)]
        e1 = sweep(pool, cfgs)
        results["E1"] = e1
        md.append(md_table("E1. Скорость исчезновения и восстановления ресурсов (хищников нет)", e1,
                           [("need", "средняя потребность", ".2f"), ("needy", "доля голодных (>0.8)", ".2f"),
                            ("avail", "доля доступных зон", ".2f")]))
        fig_heatmap(e1, os.path.join(OUT, "fig_resources.png"))

        # E2: хищники
        e2n = sweep(pool, [(str(n), {"pred.n": n}) for n in (0, 1, 2, 3, 4)])
        e2v = sweep(pool, [(str(v), {"pred.n": 2, "pred.speed": v}) for v in (1.6, 2.0, 2.4, 3.0)])
        results["E2_count"], results["E2_speed"] = e2n, e2v
        cols = [("survivors", "выжившие (доля)", ".2f"), ("groups", "групп", ".1f"),
                ("largest", "в крупнейшей группе", ".2f"), ("panic", "доля в панике", ".2f"),
                ("need", "потребность", ".2f")]
        md.append(md_table("E2a. Число хищников (скорость 2.4)", e2n, cols))
        md.append(md_table("E2b. Скорость хищников (2 хищника; скорость животных 2.0, в панике до 3.0)", e2v, cols))
        fig_predators(e2n, e2v, os.path.join(OUT, "fig_predators.png"))

        # E3: радиусы обнаружения
        e3r = sweep(pool, [(f"{r}", {**NOPRED, "animal.resource_radius": r}) for r in (5, 15, 40, 70)])
        e3t = sweep(pool, [(f"{r}", {"pred.n": 2, "animal.threat_radius": r}) for r in (5, 10, 20, 35)])
        results["E3_resource"], results["E3_threat"] = e3r, e3t
        md.append(md_table("E3a. Радиус обнаружения ресурсов (хищников нет)", e3r,
                           [("need", "средняя потребность", ".2f"), ("needy", "доля голодных (>0.8)", ".2f"),
                            ("groups", "групп", ".1f")]))
        md.append(md_table("E3b. Радиус обнаружения угрозы (2 хищника)", e3t, cols))

        # E4: распад и восстановление стаи после угрозы
        curves, e4rows = {}, []
        for tr in (10, 20, 35):
            runs = list(pool.map(pulse_job, [(tr, s) for s in SEEDS]))
            ts = runs[0][0]
            curves[tr] = (ts, np.mean([r[1] for r in runs], 0), np.mean([r[2] for r in runs], 0),
                          np.mean([r[3] for r in runs], 0))
            # скользящее среднее по 5 отсчётам (25 шагов) гасит шум числа групп
            ma = lambda x: np.convolve(x, np.ones(5) / 5, mode="same")
            pre_w = (ts >= PULSE_START - 50) & (ts < PULSE_START)
            pulse_w = (ts >= PULSE_START) & (ts < PULSE_END + 50)
            pre_g, pre_l, peak_g, min_l, rec_t, recovered = [], [], [], [], [], 0
            for _, largest, groups, _p in runs:
                g = ma(groups)
                pg = g[pre_w].mean()
                pre_g.append(pg); pre_l.append(largest[pre_w].mean())
                peak_g.append(g[pulse_w].max()); min_l.append(ma(largest)[pulse_w].min())
                # восстановление: после ухода хищника число групп снова <= уровень до угрозы + 1
                ok = np.nonzero((ts >= PULSE_END) & (g <= pg + 1.0))[0]
                if ok.size:
                    recovered += 1
                    rec_t.append(ts[ok[0]] - PULSE_END)
            e4rows.append(dict(tr=tr, pre_g=float(np.mean(pre_g)), peak_g=float(np.mean(peak_g)),
                               pre_l=float(np.mean(pre_l)), min_l=float(np.mean(min_l)),
                               recovered=recovered, rec_t=float(np.median(rec_t)) if rec_t else float("nan")))
        results["E4"] = e4rows
        lines = ["### E4. Угроза-импульс: хищник рядом со стаей на шагах %d-%d (голод отключён, поимки отключены)\n" % (PULSE_START, PULSE_END),
                 "| Радиус угрозы | Групп до угрозы | Пик числа групп | В крупнейшей группе до | Минимум в крупнейшей | Восстановили структуру (из %d) | Медиана времени восстановления после ухода хищника, шагов |" % len(SEEDS),
                 "|---|---|---|---|---|---|---|"]
        for r in e4rows:
            lines.append(f"| {r['tr']} | {r['pre_g']:.1f} | {r['peak_g']:.1f} | {r['pre_l']:.2f} | {r['min_l']:.2f} | {r['recovered']} | {r['rec_t']:.0f} |")
        md.append("\n".join(lines) + "\n")
        fig_pulse(curves, os.path.join(OUT, "fig_pulse.png"))

    fig_snapshots(os.path.join(OUT, "fig_snapshots.png"))
    with open(os.path.join(OUT, "tables.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(md))
    with open(os.path.join(OUT, "results.json"), "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=1, default=float)
    print("\n".join(md))


if __name__ == "__main__":
    main()

"""
Лабораторная работа, вариант №5: симуляция миграции животных в сезонной среде.

Boids (центрирование, выравнивание, разделение) + дополнительные правила:
  * Foraging           - движение к ближайшей доступной зоне пищи или воды
  * Predator Avoidance - уход от хищника (+ бегство к безопасной зоне)
  * Сезонная среда     - зоны ресурсов исчезают, восстанавливаются и перемещаются

Запуск интерактивной визуализации:
    python migration.py
    python migration.py --predators 2 --boundary wrap --n 50

Зависимости: numpy, matplotlib.

Структура (всё, что нужно менять, - в dataclass-ах ниже):
    EnvParams / AnimalParams / RuleWeights / ResourceParams / PredatorParams -> Config
    World        - модель мира: зоны, животные, хищники, один шаг симуляции
    metrics()    - показатели скоординированности группы
    init_scene() / update_scene() - отрисовка (используется и анимацией, и экспериментами)
    run_interactive() - анимация с ползунками
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass, field

import numpy as np

FOOD, WATER, SAFE = 0, 1, 2
SEASONS = ["Весна", "Лето", "Осень", "Зима"]


# ----------------------------------------------------------------------------
# Параметры
# ----------------------------------------------------------------------------
@dataclass
class EnvParams:
    width: float = 150.0
    height: float = 100.0
    boundary: str = "reflect"     # "reflect" - отражение, "wrap" - циклическая граница
    dt: float = 1.0
    season_length: int = 400      # длительность сезона (шагов)
    n_seasons: int = 4


@dataclass
class AnimalParams:
    n_agents: int = 40
    max_speed: float = 2.0        # ограничение скорости
    min_speed: float = 0.5
    max_accel: float = 0.25       # ограничение ускорения
    perception_radius: float = 15.0   # радиус соседей для Boids
    separation_radius: float = 4.0
    resource_radius: float = 40.0     # радиус обнаружения ресурсов
    threat_radius: float = 20.0       # радиус обнаружения угрозы
    panic_mult: float = 1.5           # во сколько раз растут скорость/ускорение при угрозе
    graze_slow: float = 0.4           # замедление в зоне ресурса
    hunger_rate: float = 0.0005       # рост голода за шаг (при 0.003 стая голодает всегда, см. отчёт)
    thirst_rate: float = 0.0005       # рост жажды за шаг
    satiation_rate: float = 0.02      # насыщение за шаг в зоне ресурса


@dataclass
class RuleWeights:
    cohesion: float = 0.01
    alignment: float = 0.05
    separation: float = 0.1
    forage: float = 0.2           # поиск ресурсов (умножается на уровень потребности 0..1)
    flee: float = 0.8             # уход от хищника
    safe: float = 0.15            # бегство к безопасной зоне при угрозе
    explore: float = 0.03         # случайный поиск, если ресурсов не видно


@dataclass
class ResourceParams:
    depletion_rate: float = 0.01  # скорость исчезновения зоны при смене сезона (за шаг)
    regen_rate: float = 0.004     # скорость восстановления зоны (за шаг)
    graze_rate: float = 0.0005    # расход ресурса одним животным за шаг
    min_available: float = 0.2    # ниже этого уровня зона считается недоступной


@dataclass
class PredatorParams:
    n: int = 1
    speed: float = 2.4
    detect_radius: float = 40.0
    catch_radius: float = 2.0
    cooldown: int = 100           # пауза после поимки (хищник сыт)
    mode: str = "chase"           # "chase" - преследует ближайшее животное, "random" - блуждает


@dataclass
class Config:
    env: EnvParams = field(default_factory=EnvParams)
    animal: AnimalParams = field(default_factory=AnimalParams)
    weights: RuleWeights = field(default_factory=RuleWeights)
    res: ResourceParams = field(default_factory=ResourceParams)
    pred: PredatorParams = field(default_factory=PredatorParams)


# Зоны: (тип, радиус, позиции по сезонам в долях размеров карты)
ZONE_SPECS = [
    (FOOD, 9, [(0.20, 0.80), (0.50, 0.80), (0.80, 0.60), (0.50, 0.20)]),
    (FOOD, 9, [(0.80, 0.20), (0.80, 0.70), (0.40, 0.40), (0.20, 0.30)]),
    (FOOD, 9, [(0.50, 0.50), (0.20, 0.20), (0.60, 0.15), (0.85, 0.85)]),
    (WATER, 8, [(0.10, 0.50), (0.10, 0.50), (0.90, 0.50), (0.90, 0.50)]),
    (WATER, 8, [(0.50, 0.05), (0.50, 0.95), (0.50, 0.05), (0.50, 0.95)]),
    (SAFE, 10, [(0.15, 0.12)] * 4),
    (SAFE, 10, [(0.85, 0.88)] * 4),
]


def _limit(vec: np.ndarray, max_len) -> np.ndarray:
    length = np.linalg.norm(vec, axis=1, keepdims=True)
    max_len = np.asarray(max_len, dtype=float).reshape(-1, 1) if np.ndim(max_len) else max_len
    return vec * np.minimum(1.0, max_len / np.maximum(length, 1e-9))


def _clamp_min(vec: np.ndarray, min_len) -> np.ndarray:
    length = np.linalg.norm(vec, axis=1, keepdims=True)
    min_len = np.asarray(min_len, dtype=float).reshape(-1, 1) if np.ndim(min_len) else min_len
    return vec * np.maximum(1.0, min_len / np.maximum(length, 1e-9))


# ----------------------------------------------------------------------------
# Модель мира
# ----------------------------------------------------------------------------
class World:
    def __init__(self, cfg: Config | None = None, seed: int | None = None):
        self.cfg = cfg or Config()
        self.rng = np.random.default_rng(seed)
        self.size = np.array([self.cfg.env.width, self.cfg.env.height], dtype=float)
        # зоны
        S = self.cfg.env.n_seasons
        self.zkind = np.array([s[0] for s in ZONE_SPECS])
        self.zr = np.array([s[1] for s in ZONE_SPECS], dtype=float)
        self.anchors = np.array([[np.array(p) * self.size for p in s[2][:S]] for s in ZONE_SPECS])
        self.reset()

    def reset(self):
        c, n = self.cfg, self.cfg.animal.n_agents
        self.t, self.season, self.kills = 0, 0, 0
        self.kill_times: list[int] = []
        # зоны
        self.zpos = self.anchors[:, 0].copy()
        self.ztarget = self.zpos.copy()
        self.zamt = np.ones(len(self.zkind))
        self.zmoving = np.zeros(len(self.zkind), dtype=bool)
        # животные
        self.pos = self.rng.random((n, 2)) * self.size
        ang = self.rng.random(n) * 2 * np.pi
        spd = self.rng.uniform(c.animal.min_speed, c.animal.max_speed, n)
        self.vel = np.stack([np.cos(ang), np.sin(ang)], 1) * spd[:, None]
        self.hunger = self.rng.uniform(0, 0.5, n)
        self.thirst = self.rng.uniform(0, 0.5, n)
        self.alive = np.ones(n, dtype=bool)
        self.panic = np.zeros(n, dtype=bool)
        self.protected = np.zeros(n, dtype=bool)
        # хищники
        k = c.pred.n
        self.ppos = self.rng.random((k, 2)) * self.size
        self.pvel = np.zeros((k, 2))
        self.pheading = self.rng.random(k) * 2 * np.pi
        self.pcool = np.zeros(k, dtype=int)

    # -- вспомогательное --------------------------------------------------------
    def _wrapd(self, d):
        if self.cfg.env.boundary == "wrap":
            d = d - self.size * np.round(d / self.size)
        return d

    def _boundary(self, P, V):
        if self.cfg.env.boundary == "wrap":
            P %= self.size
        else:
            for k in range(2):
                lo, hi = P[:, k] < 0, P[:, k] > self.size[k]
                P[lo, k] *= -1
                P[hi, k] = 2 * self.size[k] - P[hi, k]
                V[lo | hi, k] *= -1
        return P, V

    # -- один шаг ---------------------------------------------------------------
    def step(self):
        self.t += 1
        self._update_zones()
        self._step_animals()
        self._step_predators()

    # -- сезонная динамика ресурсов -----------------------------------------------
    def _update_zones(self):
        e, r = self.cfg.env, self.cfg.res
        if self.t % e.season_length == 0:
            self.season = (self.t // e.season_length) % e.n_seasons
            target = self.anchors[:, self.season]
            changed = (np.abs(target - self.zpos).max(axis=1) > 1e-6) & (self.zkind != SAFE)
            self.zmoving |= changed
            self.ztarget = target.copy()
        mv = self.zmoving
        self.zamt[mv] -= r.depletion_rate              # исчезновение
        gone = mv & (self.zamt <= 0)
        self.zpos[gone] = self.ztarget[gone]           # перемещение
        self.zamt[gone] = 0.0
        self.zmoving[gone] = False
        grow = (self.zkind != SAFE) & ~self.zmoving & ~gone
        self.zamt[grow] = np.minimum(1.0, self.zamt[grow] + r.regen_rate)   # восстановление
        self.zamt[self.zkind == SAFE] = 1.0

    # -- животные ------------------------------------------------------------------
    def _step_animals(self):
        c = self.cfg
        a, w, res = c.animal, c.weights, c.res
        self.panic[:] = False
        idx = np.nonzero(self.alive)[0]
        m = idx.size
        if m == 0:
            return
        P, V = self.pos[idx], self.vel[idx]
        ar = np.arange(m)

        # --- правила Boids ---
        d = self._wrapd(P[None, :, :] - P[:, None, :])        # d[i, j]: от i к j
        dist = np.hypot(d[..., 0], d[..., 1])
        eye = np.eye(m, dtype=bool)
        neigh = (dist < a.perception_radius) & ~eye
        cnt = neigh.sum(1, keepdims=True)
        has, cntm = cnt > 0, np.maximum(cnt, 1)
        coh = np.where(has, (neigh[..., None] * d).sum(1) / cntm, 0.0)
        ali = np.where(has, (neigh.astype(float) @ V) / cntm - V, 0.0)
        close = (dist < a.separation_radius) & ~eye
        sep = -(close[..., None] * d).sum(1)

        # --- поиск ресурсов (ближайшая доступная зона нужного типа) ---
        H, T = self.hunger[idx], self.thirst[idx]
        want_food = H >= T
        need = np.where(want_food, H, T)
        wanted = np.where(want_food, FOOD, WATER)
        dz = self._wrapd(self.zpos[None, :, :] - P[:, None, :])
        dzd = np.hypot(dz[..., 0], dz[..., 1])
        avail = (self.zamt >= res.min_available) & (self.zkind != SAFE)
        ok = (avail[None, :] & (self.zkind[None, :] == wanted[:, None])
              & ((dzd - self.zr[None, :]) < a.resource_radius))
        dm = np.where(ok, dzd, np.inf)
        j = dm.argmin(1)
        found = np.isfinite(dm[ar, j])
        tdist = dzd[ar, j]
        unit_t = dz[ar, j] / np.maximum(tdist, 1e-9)[:, None]
        grazing = found & (tdist < self.zr[j])
        pull = found & (tdist > 0.5 * self.zr[j])
        forage = np.where(pull[:, None], unit_t, 0.0) * need[:, None]
        ang = self.rng.random(m) * 2 * np.pi
        explore = np.stack([np.cos(ang), np.sin(ang)], 1) * (~found)[:, None]

        # --- избегание хищников ---
        if self.ppos.shape[0] > 0:
            dp = self._wrapd(self.ppos[None, :, :] - P[:, None, :])
            dpd = np.hypot(dp[..., 0], dp[..., 1])
            thr = dpd < a.threat_radius
            panic = thr.any(1)
            up = dp / np.maximum(dpd, 1e-9)[..., None]
            flee = -(thr[..., None] * up * (1 - dpd / a.threat_radius)[..., None]).sum(1)
        else:
            panic, flee = np.zeros(m, dtype=bool), np.zeros((m, 2))

        # --- безопасные зоны ---
        safe_mask = self.zkind == SAFE
        protected = (dzd < self.zr[None, :])[:, safe_mask].any(1)
        ds = np.where(safe_mask[None, :] & ((dzd - self.zr[None, :]) < a.resource_radius), dzd, np.inf)
        js = ds.argmin(1)
        fs = np.isfinite(ds[ar, js]) & panic & ~protected
        safe_vec = np.where(fs[:, None], dz[ar, js] / np.maximum(dzd[ar, js], 1e-9)[:, None], 0.0)

        # --- сумма управляющих векторов, ограничения ---
        acc = (w.cohesion * coh + w.alignment * ali + w.separation * sep + w.forage * forage
               + w.flee * flee + w.safe * safe_vec + w.explore * explore)
        boost = np.where(panic, a.panic_mult, 1.0)
        acc = _limit(acc, a.max_accel * boost)                       # ограничение ускорения
        V = V + acc * c.env.dt
        vmax = a.max_speed * boost * np.where(grazing, a.graze_slow, 1.0)
        V = _limit(V, vmax)                                          # ограничение скорости
        V = _clamp_min(V, np.where(grazing, 0.1, a.min_speed))
        P = P + V * c.env.dt
        P, V = self._boundary(P, V)

        # --- потребности и потребление ресурсов ---
        g_food, g_water = grazing & want_food, grazing & ~want_food
        self.hunger[idx] = np.clip(H + a.hunger_rate - a.satiation_rate * g_food, 0, 1)
        self.thirst[idx] = np.clip(T + a.thirst_rate - a.satiation_rate * g_water, 0, 1)
        np.add.at(self.zamt, j[grazing], -res.graze_rate)
        np.clip(self.zamt, 0, 1, out=self.zamt)

        self.pos[idx], self.vel[idx] = P, V
        self.panic[idx] = panic
        self.protected[:] = False
        self.protected[idx] = protected

    # -- хищники -------------------------------------------------------------------
    def _step_predators(self):
        p = self.cfg.pred
        for k in range(self.ppos.shape[0]):
            resting = self.pcool[k] > 0
            if resting:
                self.pcool[k] -= 1
            prey = np.nonzero(self.alive & ~self.protected)[0]
            target_dir, tdist = None, np.inf
            if prey.size:
                dd = self._wrapd(self.pos[prey] - self.ppos[k])
                dist = np.hypot(dd[:, 0], dd[:, 1])
                jn = dist.argmin()
                tdist = dist[jn]
                if p.mode == "chase" and not resting and tdist < p.detect_radius:
                    target_dir = dd[jn] / max(tdist, 1e-9)
            if target_dir is not None:
                step = min(p.speed, tdist)
                vel = target_dir * step
            else:
                self.pheading[k] += self.rng.normal(0, 0.3)
                speed = p.speed * (0.2 if resting else 0.5)
                vel = np.array([np.cos(self.pheading[k]), np.sin(self.pheading[k])]) * speed
            P1, V1 = self._boundary((self.ppos[k] + vel)[None, :], vel[None, :].copy())
            self.ppos[k], self.pvel[k] = P1[0], V1[0]
            # поимка ближайшего незащищённого животного
            if not resting and prey.size:
                dd = self._wrapd(self.pos[prey] - self.ppos[k])
                dist = np.hypot(dd[:, 0], dd[:, 1])
                jn = dist.argmin()
                if dist[jn] < p.catch_radius:
                    self.alive[prey[jn]] = False
                    self.kills += 1
                    self.kill_times.append(self.t)
                    self.pcool[k] = p.cooldown


# ----------------------------------------------------------------------------
# Метрики
# ----------------------------------------------------------------------------
def metrics(world: World, cluster_radius: float = 12.0) -> dict:
    """alive, groups (число групп), largest (доля в крупнейшей группе),
    polarization, need (средняя максимальная потребность), panic (доля в панике)."""
    idx = np.nonzero(world.alive)[0]
    m = idx.size
    if m == 0:
        return dict(alive=0, groups=0, largest=0.0, polarization=0.0, need=0.0, panic=0.0)
    P, V = world.pos[idx], world.vel[idx]
    d = world._wrapd(P[None] - P[:, None])
    adj = np.hypot(d[..., 0], d[..., 1]) < cluster_radius
    seen = np.zeros(m, dtype=bool)
    sizes = []
    for s in range(m):
        if seen[s]:
            continue
        stack, comp = [s], 0
        seen[s] = True
        while stack:
            u = stack.pop()
            comp += 1
            for v in np.nonzero(adj[u] & ~seen)[0]:
                seen[v] = True
                stack.append(v)
        sizes.append(comp)
    unit = V / np.maximum(np.linalg.norm(V, axis=1, keepdims=True), 1e-9)
    need = np.maximum(world.hunger[idx], world.thirst[idx])
    return dict(alive=m, groups=len(sizes), largest=max(sizes) / m,
                polarization=float(np.linalg.norm(unit.mean(0))),
                need=float(need.mean()), panic=float(world.panic[idx].mean()))


# ----------------------------------------------------------------------------
# Отрисовка
# ----------------------------------------------------------------------------
def init_scene(ax, w: World) -> dict:
    from matplotlib.colors import ListedColormap
    from matplotlib.patches import Circle

    ax.set_xlim(0, w.size[0])
    ax.set_ylim(0, w.size[1])
    ax.set_aspect("equal")
    colors = {FOOD: "tab:green", WATER: "deepskyblue", SAFE: "goldenrod"}
    patches = []
    for i in range(len(w.zkind)):
        k = w.zkind[i]
        circ = Circle(w.zpos[i], w.zr[i], facecolor=colors[k], edgecolor=colors[k],
                      lw=1.5, ls="--" if k == SAFE else "-")
        ax.add_patch(circ)
        patches.append(circ)
    # стрелок всегда n_agents (число фиксировано в quiver); съеденные уводятся за поле в update_scene
    quiv = ax.quiver(w.pos[:, 0], w.pos[:, 1], w.vel[:, 0], w.vel[:, 1],
                     w.panic.astype(float), angles="xy", scale_units="xy", scale=0.7,
                     width=0.004, headwidth=4, headlength=5,
                     cmap=ListedColormap(["#333333", "orange"]), clim=(0, 1), zorder=4)
    preds = ax.scatter(w.ppos[:, 0], w.ppos[:, 1], marker="^", s=140, c="red",
                       edgecolors="k", zorder=5)
    info = ax.text(0.01, 0.99, "", transform=ax.transAxes, va="top", fontsize=9,
                   bbox=dict(facecolor="white", alpha=0.75, edgecolor="none"), zorder=6)
    return dict(ax=ax, patches=patches, quiv=quiv, preds=preds, info=info)


def update_scene(sc: dict, w: World):
    for i, circ in enumerate(sc["patches"]):
        circ.set_center(w.zpos[i])
        circ.set_alpha(0.15 if w.zkind[i] == SAFE else 0.12 + 0.55 * w.zamt[i])
    alive = w.alive
    sc["quiv"].set_offsets(np.where(alive[:, None], w.pos, -1e4))      # съеденных не видно
    sc["quiv"].set_UVC(np.where(alive, w.vel[:, 0], 0.0), np.where(alive, w.vel[:, 1], 0.0),
                       w.panic.astype(float))
    sc["preds"].set_offsets(w.ppos)
    m = metrics(w)
    sc["info"].set_text(f"сезон: {SEASONS[w.season % len(SEASONS)]}  (t={w.t})\n"
                        f"живых: {m['alive']}   съедено: {w.kills}\n"
                        f"групп: {m['groups']}   в крупнейшей: {m['largest']:.0%}\n"
                        f"средняя потребность: {m['need']:.2f}")


def run_interactive(world: World):
    import matplotlib.pyplot as plt
    from matplotlib.animation import FuncAnimation
    from matplotlib.widgets import Button, Slider

    fig, ax = plt.subplots(figsize=(10, 9))
    plt.subplots_adjust(left=0.06, right=0.97, top=0.95, bottom=0.43)
    ax.set_title("Миграция животных: зелёные - пища, голубые - вода, пунктир - убежища, "
                 "красные треугольники - хищники", fontsize=9)
    sc = init_scene(ax, world)
    c = world.cfg
    specs = [
        ("Исчезновение ресурсов", 0.002, 0.05, c.res.depletion_rate, lambda v: setattr(c.res, "depletion_rate", v)),
        ("Восстановление ресурсов", 0.0005, 0.02, c.res.regen_rate, lambda v: setattr(c.res, "regen_rate", v)),
        ("Радиус обнаружения ресурсов", 5, 80, c.animal.resource_radius, lambda v: setattr(c.animal, "resource_radius", v)),
        ("Радиус обнаружения угрозы", 3, 50, c.animal.threat_radius, lambda v: setattr(c.animal, "threat_radius", v)),
        ("Скорость хищников", 0.5, 4, c.pred.speed, lambda v: setattr(c.pred, "speed", v)),
        ("Длина сезона (шагов)", 100, 1000, c.env.season_length, lambda v: setattr(c.env, "season_length", int(v))),
    ]
    sliders = []
    for i, (label, lo, hi, init, cb) in enumerate(specs):
        sax = fig.add_axes([0.30, 0.35 - i * 0.045, 0.62, 0.03])
        s = Slider(sax, label, lo, hi, valinit=init)
        s.on_changed(cb)
        sliders.append(s)
    bax = fig.add_axes([0.06, 0.02, 0.12, 0.04])
    btn = Button(bax, "Сброс")
    btn.on_clicked(lambda _e: world.reset())

    def update(_frame):
        world.step()
        update_scene(sc, world)
        return []

    fig._keep = (sliders, btn)
    fig._anim = FuncAnimation(fig, update, interval=30, blit=False, cache_frame_data=False)
    plt.show()


def main():
    p = argparse.ArgumentParser(description="Boids: миграция животных в сезонной среде")
    p.add_argument("--n", type=int, default=40, help="число животных (30-50)")
    p.add_argument("--predators", type=int, default=1)
    p.add_argument("--pred-mode", choices=["chase", "random"], default="chase")
    p.add_argument("--boundary", choices=["reflect", "wrap"], default="reflect")
    p.add_argument("--seed", type=int, default=None)
    args = p.parse_args()

    cfg = Config()
    cfg.animal.n_agents = args.n
    cfg.pred.n = args.predators
    cfg.pred.mode = args.pred_mode
    cfg.env.boundary = args.boundary
    run_interactive(World(cfg, seed=args.seed))


if __name__ == "__main__":
    main()
